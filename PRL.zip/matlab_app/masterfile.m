% Master calls for determining saddle splay modulus from pressure profile
% (c) Wageningen University
%  
% R.Varadharajan (2017).

function [kbar, kc] = masterfile(x,y,c)
start = cputime;
for loop1=1:1
    chi = c;%obtain from input
      
    startval = x%obtain from input20;
    step = 1
    endval =  y%obtain from input20;
    [n] = create_input(chi,startval,endval,step);
    for loop2=1:3
        disp('In loop')
        run_input;
        equate_to_solvent(chi,startval,endval,step);
    end
    input_sphere(chi,startval,endval,step);
    runsphere;
    [kbar, kc] = saddle_splay_modulus_from_p(n,startval,endval,step);

end
stop=cputime;
system('rm input*.dat input*.kal input*.pro')
disp('Problems succesfully done!.');

