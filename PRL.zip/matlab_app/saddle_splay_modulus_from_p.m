%pressure profile to saddle splay modulus

% Reads the output files generated using SFbox.
% Contains functions to plot data and analyse data.
% Calculates the k_c value based on new protocol
function [kbar, kc1] = saddle_splay_modulus_from_p(n,startval,endval,step)

pol=zeros(20,2);
num=zeros(n,1);
count=zeros(n,1);
for j=1:n
filename=sprintf('input_%i_2.pro',j);
M=dlmread(filename,'\t',1,0);
filename2=sprintf('input_%i.kal',j);
N=dlmread(filename2,'\t',1,0);
filename3=sprintf('input_sphere_%i.kal',j);
O=dlmread(filename3,'\t',1,0);
omegasphere=O(1,1)/(4*pi);
plane=N(1,13);
x=M(:,1);
y=M(:,3);
prof=M(:,7);

for i=1:100
    if(i<plane)
    count(j) = count(j) + (i-plane)*(i-plane)*(-1)*(y(1)-y(i)); 
    else
        count(j) = count(j) + (i-plane)*(i-plane)*(-1)*(y(100)-y(i)); 
    end
end
num(j)=(j-1)*step+startval;
%num(j)=log10(num(j));
kc(j) = (omegasphere-count(j))/2;
%count(j)=log10(-1*count(j));
%pol(k,:) = polyfit(num,count,1);
dy=linspace(1,101,1000);
y=-y;
y=interp1(y,dy,'spline');
%axes(handles.axes1);
%plot(dy,y)
%xlim([1 100])
%xlabel('$z$','Interpreter','latex')
%ylabel('$p(z)$','Interpreter','latex')
%hold on
%axes(handles.axes3);
plot(M(:,1),M(:,7),M(:,1),M(:,8),M(:,1),M(:,9))
l=legend('$\varphi_A$','$\varphi_B$','$\varphi_{pol}$');
set(l,'Interpreter','latex');
set(l,'FontSize',20);
xlim([1 100])
ylim([0 1])
xlabel('$z$','Interpreter','latex', 'FontSize',20);
ylabel('$\varphi$','Interpreter','latex', 'FontSize',20);
end

kc1 = kc(n);
kbar = count(n);


% p=plot(num,count,'-black')
% p(1).LineWidth=2;
% %h = legend('$\bar{k}$');
% %set(h,'Interpreter','latex')
% ax=gca;
% ax.YAxis.Exponent=0;
% set(gca,'FontSize',20)
% set(gca,'Fontname','Times')
% xlabel('$N$','Interpreter','latex')
% ylabel('$\bar{k}$','Interpreter','latex')

% filename=sprintf('critical_scaling.dat');
% file=fopen(filename,'a');
% for i=1:n
% fprintf(file,'%0.16f \t %0.16f \t %0.16f \r\n',chi,count(i),kc(i));
% end

% system('mkdir data');
% system('mv input*.pro input*.kal input*.dat data/');
