% Input generator for flat geometery and varying a specific parameter
% developed by Ram

% ==================================================================
% Recent edits log
% ------------------------------------------------------------------
% Name	|	Description				| Date
% ------------------------------------------------------------------
% Ram	| creates input for flat geometry only.		|06,Nov,2016
% Ram	| Varies surfactant chain length from 16 - 20,
%	  and number of layers increased to 100. 	|16,Nov,2016
%===================================================================



function [n] = input_sphere(c,x,y,z)

initial_value = x;	% Initial value of the variable to be changed 
step = z; 		% steps in which inital value is to be changed
end_value = x;		% End value of the variable to be changed 
disp('Computing number of files to be created');
n = ((end_value-initial_value)/step + 1);
disp('Creating an array of variable values');

variable(n)=0;
for i = 1:n
     variable(i) = initial_value + step*(i-1);
end


for i = 1:n
     filename = sprintf('input_%d.kal',i);
     N = dlmread(filename,'\t',1,0);
     phia_1(i) = N(1,6);
     phib_1(i) = N(1,3);
     phipol_1(i) = N(1,9);
     radius(i) = N(1,13);
     poltheta(i) = N(1,11);
     
     A_theta(i) = (phia_1(i)-phib_1(i))*(4/3)*pi*radius(i)*radius(i)*radius(i) ...
         + phib_1(i)*(4/3)*pi*100*100*100 - phipol_1(i)*(4/3)*pi*100*100*100;
     A_theta(i) = int64(A_theta(i));
     poltheta(i) = poltheta(i)*4*pi*radius(i)*radius(i) + N(1,9)*(4/3)*pi*100*100*100;
     poltheta(i) = 1.0;%int64(poltheta(i));
end


for j = 1:n
    fprintf('Creating input file %d\n',j);

    % Several input files with name input_(index).dat will be created
    filename = sprintf('input_sphere_%d.dat',j);
    file = fopen(filename,'w');

    % Generating Grid
    % grid parameters
    gridname = 'cyl';
    n_layers = 100;
    geometry = 'spherical';
    lambda = 1/3;
    gradients = 1;
    upper_boundary = 'mirror1';
    lower_boundary = 'mirror1';
    % format for inputs
    formatSpec_layers = 'lat : %s : n_layers : %d\r\n';
    formatSpec_lambda = 'lat : %s : lambda : %.16f\r\n';
    formatSpec_geometry = 'lat : %s : geometry : %s\r\n';
    formatSpec_gradients = 'lat : %s : gradients : %d\r\n';
    formatSpec_up_bound = 'lat : %s : upperbound : %s\r\n';
    formatSpec_lo_bound = 'lat : %s : lowerbound : %s\r\n';
    % file writing
    fprintf(file,formatSpec_layers, gridname, n_layers);
    fprintf(file,formatSpec_lambda, gridname, lambda);
    fprintf(file,formatSpec_geometry, gridname, geometry);
    fprintf(file,formatSpec_gradients, gridname, gradients);
    fprintf(file,formatSpec_lo_bound, gridname, lower_boundary);
    fprintf(file,formatSpec_up_bound, gridname, upper_boundary);
    fprintf(file,'\r\n');


    % Creating Monomers
    % Creating required number of monomers

    % 1st monomer parameters
    mon_name = 'A';
    freedom = 'pinned';
    pinned_rangefrom = 1;
    pinned_rangeto = 80;
    int_with = 'B';
    chival = c;
    % writing in file
    formatSpec_freedom = 'mon : %s : freedom : %s\r\n';
    fprintf(file, formatSpec_freedom, mon_name, freedom);
    formatSpec_pin_range = 'mon : %s : pinned_range : %d;%d\r\n';
    fprintf(file, formatSpec_pin_range, mon_name, pinned_rangefrom,...
        pinned_rangeto);
    formatSpec_freedom = 'mon : %s : chi - %s : %.16f\r\n';
    fprintf(file, formatSpec_freedom, mon_name, int_with, chival);
    % 2nd monomer parameters
    mon_name = 'B';
    freedom = 'free';
    % writing in file
    formatSpec_freedom = 'mon : %s : freedom : %s\r\n';
    fprintf(file, formatSpec_freedom, mon_name, freedom);
    fprintf(file,'\r\n');


    % Creating Molecules from monomers
    % Creating 1st Molecule
        mol_name1 = 'A';
        composition = y;
        freedom = 'restricted';
        theta = A_theta(j);
        %writing in file
        formatSpec_comp = 'mol : %s : composition : (%s)%d\r\n';
        formatSpec_freedom = 'mol : %s : freedom : %s\r\n';
        formatSpec_th = 'mol : %s : theta : %d\r\n';
        fprintf(file, formatSpec_comp, mol_name1, mol_name1, composition);
        fprintf(file, formatSpec_freedom, mol_name1, freedom);
        fprintf(file, formatSpec_th, mol_name1, theta);
    % Creating 2nd Molecule
        mol_name2 = 'B';
        composition = y;
        freedom = 'solvent';
        %writing in file
        fprintf(file, formatSpec_comp, mol_name2, mol_name2, composition);
        fprintf(file, formatSpec_freedom, mol_name2, freedom);

    % Creating Polymer Molecule
        surf_name = 'pol';
        compos1 = variable(j);
        compos2 = variable(j);
        freedom = 'restricted';
        theta = poltheta(j);
        %writing in file
        formatSpec_comp = 'mol : %s : composition : (%s)%d(%s)%d\r\n';
        formatSpec_freedom = 'mol : %s : freedom : %s\r\n';
        formatSpec_th = 'mol : %s : theta : %16f\r\n';
        fprintf(file, formatSpec_comp, surf_name, mol_name1, compos1, ...
            mol_name2, compos2);
        fprintf(file, formatSpec_freedom, surf_name, freedom);
        fprintf(file, formatSpec_th, surf_name, theta);

    fprintf(file,'\r\n');
    fprintf(file,'start\r\n');
    fprintf(file,'mon : A : freedom : free\r\n');
    fprintf(file,'\r\n');
    
          formatSpec_comp = 'mol : %s : composition : (%s)%d(%s)%d\r\n';
        formatSpec_freedom = 'mol : %s : freedom : %s\r\n';
        formatSpec_th = 'mol : %s : phibulk : %16f\r\n';
%         fprintf(file, 'mol : pol : composition : (A)20(B)20\r\n');
%         fprintf(file, 'mol : pol : freedom : free\r\n');
%         fprintf(file, 'mol : pol : phibulk : %.16f\r\n', phipol_1(j));


    fprintf(file,'sys : cylinder : extra_output : interfacial_width \r\n');
    fprintf(file,'sys : cylinder : Gibbs_molecule : B \r\n');
    fprintf(file,'\r\n');

    % writing the iteration techniques to file
    fprintf(file, 'newton : isaac : method : pseudohessian\r\n');
    fprintf(file, 'newton : isaac : transfer_hessian : true\r\n');
    fprintf(file, 'newton : isaac : n_iterations_for_hessian : 200\r\n');
    
    fprintf(file, 'newton : isaac : tolerance : 1e-12\r\n');
    %fprintf(file, 'newton : isaac : iterationlimit : 20000\r\n');
    fprintf(file, 'newton : isaac : e_info : false\r\n');
    fprintf(file, 'newton : isaac : s_info : true\r\n');
    fprintf(file,'\r\n');


%     %fixing phib
%     fprintf(file,'start\r\n');
%     fprintf(file,'mol : pol : freedom : free\r\n');
%     fprintf(file,'mol : pol : phibulk : %.16f\r\n', phipol_1(j));

%     %superiteration
    fprintf(file,'sys: cylinder: super_iteration: true\r\n');
    fprintf(file,'sys: cylinder: super_molecule: pol\r\n');
    fprintf(file,'sys: cylinder: super_function: P_Laplace\r\n');
    fprintf(file,'sys: cylinder: super_function_value: 0\r\n');

    %fprintf(file,'sys: cylinder: iterate_lattice_artefact : true\r\n');

    % writing output formats to file
    fprintf(file, 'output : filename.pro : type : profiles\r\n');
    fprintf(file, 'output : filename.pro : template : temp.pro\r\n');
    fprintf(file, 'output : filename.pro : write_bounds : false\r\n');
    fprintf(file, 'output : filename.kal : type : kal\r\n');
    fprintf(file, 'output : filename.kal : template : temp.kal\r\n');
    fprintf(file,'\r\n');


end
disp('Succesfully created all input files');
disp('Hurrrrayyy! You can Start running the inputs. :) ')






