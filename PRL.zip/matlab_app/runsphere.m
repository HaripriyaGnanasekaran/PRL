% Runs the created input files.
% Input files are created using create_input.m

for i = 1:n
     filename = sprintf('input_sphere_%d.dat',i);
     string = sprintf('./sfbox %s', filename);
     system(string);
end

